<#
PowerShell script to configure B-2 tablets
Created by Data Tech Cafe
#>

# Initialization
$rootUrl = "https://datatechcafe.com/download/dtccfg"
$appDir = "${Env:ProgramFiles}\dtccfg"
$backgroundImageFile = "BRAINtellect-2-background-logo-1280x1280.png"

# Set background image
Invoke-WebRequest -Uri "$rootUrl/$backgroundImageFile" -OutFile "$appDir\$backgroundImageFile"
Invoke-WebRequest -Uri "$rootUrl/Set-Wallpaper.ps1" -OutFile "$appDir\Set-Wallpaper.ps1"
Invoke-Expression "& `"$appDir\Set-Wallpaper.ps1`" MyPics `"$backgroundImageFile`" "
